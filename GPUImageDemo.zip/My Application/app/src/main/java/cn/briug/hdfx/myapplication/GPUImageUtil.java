package cn.briug.hdfx.myapplication;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PointF;
import android.util.Log;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

import jp.co.cyberagent.android.gpuimage.GPUImage;
import jp.co.cyberagent.android.gpuimage.GPUImage3x3ConvolutionFilter;
import jp.co.cyberagent.android.gpuimage.GPUImage3x3TextureSamplingFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageAddBlendFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageAlphaBlendFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageBilateralFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageBoxBlurFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageBrightnessFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageBulgeDistortionFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageCGAColorspaceFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageChromaKeyBlendFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageColorBalanceFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageColorBlendFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageColorBurnBlendFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageColorDodgeBlendFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageColorInvertFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageColorMatrixFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageContrastFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageCrosshatchFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageDarkenBlendFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageDifferenceBlendFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageDilationFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageDirectionalSobelEdgeDetectionFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageDissolveBlendFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageDivideBlendFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageEmbossFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageExclusionBlendFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageExposureFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageFalseColorFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageFilterGroup;
import jp.co.cyberagent.android.gpuimage.GPUImageGammaFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageGaussianBlurFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageGlassSphereFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageGrayscaleFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageHalftoneFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageHardLightBlendFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageHazeFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageHighlightShadowFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageHueBlendFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageHueFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageKuwaharaFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageLaplacianFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageLevelsFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageLightenBlendFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageLinearBurnBlendFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageLookupFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageLuminosityBlendFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageMixBlendFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageMonochromeFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageMultiplyBlendFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageNonMaximumSuppressionFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageNormalBlendFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageOpacityFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageOverlayBlendFilter;
import jp.co.cyberagent.android.gpuimage.GPUImagePixelationFilter;
import jp.co.cyberagent.android.gpuimage.GPUImagePosterizeFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageRGBDilationFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageRGBFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageSaturationBlendFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageSaturationFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageScreenBlendFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageSepiaFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageSharpenFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageSketchFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageSmoothToonFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageSobelThresholdFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageSoftLightBlendFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageSourceOverBlendFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageSphereRefractionFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageSubtractBlendFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageSwirlFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageToneCurveFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageToonFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageTransformFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageTwoInputFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageTwoPassFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageTwoPassTextureSamplingFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageVignetteFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageWeakPixelInclusionFilter;
import jp.co.cyberagent.android.gpuimage.GPUImageWhiteBalanceFilter;


/**
 * 滤镜模式
 */

public class GPUImageUtil {

    private static GPUImageFilter filter;
    //饱和度、亮度等参数指数
//    private static float count;

    /**
     * 获取过滤器
     *
     * @param GPUFlag
     * @return 滤镜类型
     */
    public static GPUImageFilter getFilter(int GPUFlag, float count) {
        switch (GPUFlag) {
            case 1:
                /**
                 * --CGA色彩空间
                 * CGA色彩滤镜，形成黑、浅蓝、紫色块的画面
                 */
                filter = new GPUImageCGAColorspaceFilter();
                break;
            case 2:
                /**
                 *--色彩平衡
                 */
                filter = new GPUImageColorBalanceFilter();
                break;
            case 3:
                /**
                 * --反转颜色
                 */
                filter = new GPUImageColorInvertFilter();
                break;
            case 4:
                /**
                 *
                 */
                filter = new GPUImageDirectionalSobelEdgeDetectionFilter();
                break;
            case 5:
                /**
                 * --变暗模糊效果
                 * 通常用于创建两个图像之间的动画变暗模糊效果
                 */
                filter = new GPUImageDivideBlendFilter();
                break;
            case 6:
                /**
                 * --灰度
                 * 将图像转换为灰度级（稍微更快的饱和度滤镜实现，无需改变颜色贡献）
                 */
                filter = new GPUImageGrayscaleFilter();
                break;

            case 7:
                /**
                 * --阴影和深度
                 */
                filter = new GPUImageMultiplyBlendFilter();
                break;
            case 8:
                /**
                 * --高亮显示
                 */
                filter = new GPUImageNonMaximumSuppressionFilter();
                break;
            case 9:
                /**
                 * --叠加
                 * 通常用于创建阴影效果
                 */
                filter = new GPUImageOverlayBlendFilter();
                break;
            case 10:
                /**
                 * --像素
                 */
                filter = new GPUImagePixelationFilter();
                break;
            case 11:
                /**
                 * --像素融合
                 */
                filter = new GPUImageWeakPixelInclusionFilter();
                break;

            //混合
            case 12:
                /**
                 * --添加混合
                 * 通常用于创建两个图像之间的动画变亮模糊效果
                 */
                filter = new GPUImageAddBlendFilter();
                break;
            case 13:
                /**
                 * --颜色混合
                 */
                filter = new GPUImageColorBlendFilter();
                break;
            case 14:
                /**
                 * --色彩减淡混合
                 * 应用两个图像的颜色闪避混合
                 */
                filter = new GPUImageColorDodgeBlendFilter();
                break;
            case 15:
                /**
                 * --色彩加深混合
                 */
                filter = new GPUImageColorBurnBlendFilter();
                break;
            case 16:
                /**
                 * --加深混合
                 * 通常用于重叠类型,通过拍摄图像之间的每个颜色分量的最小值来混合两个图像
                 */
                filter = new GPUImageDarkenBlendFilter();
                break;
            case 17:
                /**
                 * --差异混合
                 * 通常用于创建更多变动的颜色
                 */
                filter = new GPUImageDifferenceBlendFilter();
                break;
            case 18:
                /**
                 * --排除混合
                 */
                filter = new GPUImageExclusionBlendFilter();
                break;
            case 19:
                /**
                 * --硬光混合
                 * 通常用于创建阴影效果
                 */
                filter = new GPUImageHardLightBlendFilter();
                break;
            case 20:
                /**
                 * --色调混合
                 * 应用两个图像的色调混合
                 */
                filter = new GPUImageHueBlendFilter();
                break;
            case 21:
                /**
                 * --减淡混合
                 * 通常用于重叠类型
                 */
                filter = new GPUImageLightenBlendFilter();
                break;
            case 22:
                /**
                 * --线性混合
                 */
                filter = new GPUImageLinearBurnBlendFilter();
                break;
            case 23:
                /**
                 * --光度混合
                 */
                filter = new GPUImageLuminosityBlendFilter();
                break;
            case 24:
                /**
                 * --正常混合
                 */
                filter = new GPUImageNormalBlendFilter();
                break;
            case 25:
                /**
                 * --差值混合
                 * 通常用于创建两个图像之间的动画变暗模糊效果
                 *
                 */
                filter = new GPUImageSubtractBlendFilter();
                break;
            case 26:
                /**
                 * --柔光混合
                 */
                filter = new GPUImageSoftLightBlendFilter();
                break;
            case 27:
                /**
                 * --源混合
                 */
                filter = new GPUImageSourceOverBlendFilter();
                break;
            case 28:
                /**
                 * --饱和度混合
                 */
                filter = new GPUImageSaturationBlendFilter();
                break;
            case 29:
                /**
                 * --屏幕混合
                 *通常用于创建亮点和镜头眩光
                 */
                filter = new GPUImageScreenBlendFilter();
                break;
            //=================================================================================================
            case 30:
                /**
                 * --亮度
                 * 调整亮度（-1.0 - 1.0，默认值为0.0）
                 */
                if (count >= -1.0 || count <= 1.0) {
                    filter = new GPUImageBrightnessFilter(count);
                } else {
                    filter = new GPUImageBrightnessFilter(0.0f);
                }
                break;
            case 31:
                /**
                 * --对比度
                 * 调整后的对比度（0.0 - 4.0，默认为1.0）
                 */
                if (count >= 0.0 || count <= 4.0) {
                    filter = new GPUImageContrastFilter(count);
                }
                filter = new GPUImageContrastFilter(1.0f);
                break;
            case 32:
                /**
                 * --透明混合
                 * 通常用于在背景上应用前景的透明度
                 * 根据第二个alpha通道将第二个图像混合在第一个图像上
                 *  mix：第二个图像覆盖第一个（0.0 - 1.0，默认值为1.0）的程度
                 */
                if (count >= 0.0 || count <= 1.0) {
                    filter = new GPUImageAlphaBlendFilter(count);
                } else {
                    filter = new GPUImageAlphaBlendFilter(1.0f);
                }
                break;
            case 33:
                /**
                 * --图像混合
                 * 溶解
                 * mix：第二个图像覆盖第一个图像的程度（0.0 - 1.0，默认值为0.5）
                 */
                if (count >= 0.0 || count <= 1.0) {
                    filter = new GPUImageDissolveBlendFilter(count);
                } else {
                    filter = new GPUImageDissolveBlendFilter(0.5f);
                }
                break;
            case 34:
                /**
                 * --浮雕
                 * 压花的强度，从0.0到4.0，以1.0为正常水平
                 */
                if (count >= 0.0 || count <= 4.0) {
                    filter = new GPUImageEmbossFilter(count);
                } else {
                    filter = new GPUImageEmbossFilter(1.0f);
                }
                break;
            case 35:
                /**
                 * --曝光
                 * 调整曝光（-10.0 - 10.0，默认为0.0）
                 */
                if (count >= -10.0 || count <= 10.0) {
                    filter = new GPUImageExposureFilter(count);
                } else {
                    filter = new GPUImageExposureFilter(0.0f);
                }
                break;
            case 36:
                /**
                 *
                 * --灰度
                 * 要应用的gamma调整（0.0 - 3.0，默认值为1.0）
                 */
                if (count >= 0.0 || count <= 3.0) {
                    filter = new GPUImageGammaFilter(count);
                } else {
                    filter = new GPUImageGammaFilter(1.0f);
                }
                break;
            case 37:
                /**
                 * --黑白化
                 * 对图像应用半色调效果，如新闻打印
                 *  fractionalWidthOfAPixel：半色调点的大小是图像宽度和高度的一部分（0.0 - 1.0，默认为0.05）
                 */
                if (count >= 0.0 || count <= 1.0) {
                    filter = new GPUImageHalftoneFilter(count);
                } else {
                    filter = new GPUImageHalftoneFilter(0.05f);
                }
                break;
            case 38:
                /**
                 * --色调
                 * 色调角度，以度为单位。默认为90度
                 */
                if (count >= 0.0 || count <= 360.0) {
                    filter = new GPUImageHueFilter(count);
                } else {
                    filter = new GPUImageHueFilter(90.0f);
                }
                break;
            case 39:
                /**
                 *  --不透明度
                 * 将每个像素的传入Alpha通道乘以（0.0 - 1.0，默认值为1.0）
                 */
                if (count >= 0.0 || count <= 1.0) {
                    filter = new GPUImageOpacityFilter(count);
                } else {
                    filter = new GPUImageOpacityFilter(1.0f);
                }

                break;
            case 40:
                /**
                 * --色调分离
                 * 这将颜色动态范围减少到指定的步骤数，从而导致类似卡通的简单阴影图像。
                 * colorLevels：减少图像空间的颜色级别数。取值范围为1〜256，缺省值为10。
                 */
                if (count >= 0.0 || count <= 1.0) {
                    filter = new GPUImagePosterizeFilter();
                } else {
                    filter = new GPUImagePosterizeFilter(10);
                }
            case 41:
                /**
                 * --褐色
                 * 棕褐色调取代正常图像颜色的程度（0.0 - 1.0，默认值为1.0）
                 */
                if (count >= 0.0 || count <= 1.0) {
                    filter = new GPUImageSepiaFilter(count);
                } else {
                    filter = new GPUImageSepiaFilter(1.0f);
                }
                break;
            case 42:
                /**
                 * --饱和度
                 * 应用于图像的饱和度或去饱和度（0.0 - 2.0，默认值为1.0）
                 */
                if (count >= 0.0 || count <= 2.0) {
                    filter = new GPUImageSaturationFilter(count);
                } else {
                    filter = new GPUImageSaturationFilter(1.0f);
                }
                break;
            case 43:
                /**
                 * --锐化
                 * 适用的锐度调整（-4.0 - 4.0，默认为0.0）
                 */
                if (count >= 0.0 || count <= 2.0) {
                    filter = new GPUImageSharpenFilter(count);
                } else {
                    filter = new GPUImageSharpenFilter(0.0f);
                }
                break;
            case 44:
                /**
                 * --映射颜色
                 *lookup 色彩调整
                 */
                filter = new GPUImageLookupFilter(1.0f);
                break;
//==================================================================================================
            case 100:
                filter = new GPUImageLaplacianFilter();
                break;
            case 101:
                filter = new GPUImageSobelThresholdFilter();
                break;
            case 102:
                filter = new GPUImage3x3TextureSamplingFilter();
                break;
            case 103:
                /**
                 * 这与GPUImageDilationFilter相同，除了它对所有颜色通道，而不仅仅是红色通道。
                 */
                filter = new GPUImageRGBDilationFilter();
                break;
//==================================================================================================
            case 45:
                /**
                 * 双边模糊，尝试在保留锐利边缘的同时模糊相似的颜色值
                 *  texelSpacingMultiplier：texel读取间距的乘数，范围从0.0开始，默认值为4.0
                 *  distanceNormalizationFactor：中心颜色和样本颜色之间的距离的归一化因子，默认值为8.0。
                 */
                filter = new GPUImageBilateralFilter();
                break;
            case 46:
                /**
                 * //盒状模糊
                 * 硬件优化，可变半径框模糊
                 *  texelSpacingMultiplier：纹素之间的间距的乘数，范围从0.0到up，默认值为1.0。
                 *  调整这可能会稍微增加模糊强度，但会在结果中引入工件。在接触这一个之前先强烈推荐使用其他参数。
                 *  blurRadiusInPixels：用于模糊的半径（以像素为单位），默认值为2.0。这调整高斯分布函数中的sigma变量。
                 *  blurRadiusAsFractionOfImageWidth：
                 *  blurRadiusAsFractionOfImageHeight：设置这些属性将允许模糊半径与图像的大小缩放
                 *  blurPasses：顺序模糊传入图像的次数。越多越好，过滤器越慢。
                 */
                filter = new GPUImageBoxBlurFilter();
                break;
            case 47:
                /**
                 * //凸起失真，鱼眼效果
                 * 在图像上创建一个凸起失真
                 *  半径：半径从中心应用失真，默认为0.25
                 *  中心：图像的中心（标准化坐标为0 - 1.0），要扭曲，默认值为（0.5,0.5）
                 *  scale：要应用的失真量，从-1.0到1.0，默认值为0.5
                 */
                filter = new GPUImageBulgeDistortionFilter();
                break;
            case 48:
                /**
                 * //色度键混合
                 * 用第二个图像选择性地替换第一个图像中的一个颜色
                 *  阈值敏感度：要替换的目标颜色需要存在多少颜色匹配（默认值为0.4）
                 *  平滑：如何平稳地融合颜色匹配（默认为0.1）
                 */
                filter = new GPUImageChromaKeyBlendFilter();
                break;
            case 49:
                /**
                 * //3x3卷积，高亮大色块变黑，加亮边缘、线条等
                 * 针对图像运行3x3卷积内核
                 * 卷积内核是要应用于像素及其8个周围像素的值的3x3矩阵。
                 * 矩阵以行主顺序指定，左上角的像素为one.one，右下方为three.three。如果矩阵中的值不能加起来为1.0，则图像可能变亮或变暗。
                 */
                filter = new GPUImage3x3ConvolutionFilter();
                break;
            case 50:
                /**
                 * 通过对它们应用矩阵来转换图像的颜色
                 *  colorMatrix：用于转换图像中每种颜色的4x4矩阵
                 *   强度：新变换颜色取代每个像素的原始颜色的程度
                 *
                 */
                filter = new GPUImageColorMatrixFilter();
                break;
            case 51:
                /**
                 * //交叉线阴影，形成黑白网状画面
                 * 将图像转换为黑白交叉影线图案
                 * crossHatchSpacing：用作交叉影线间距的图像的小数宽度。默认值为0.03。
                 *  lineWidth：交叉线的相对宽度。默认值为0.003。
                 */
                filter = new GPUImageCrosshatchFilter();
                break;
            case 52:
                /**
                 * //扩展边缘模糊，变黑白
                 * 执行图像扩张操作，其中矩形邻域中的红色通道的最大强度用于该像素的强度。
                 * 要采样的矩形区域的半径在初始化时指定，范围为1-4像素。
                 * 这是为了与灰度图像一起使用，它扩展了明亮的区域。
                 */
                filter = new GPUImageDilationFilter();
                break;
            case 53:
                /**
                 * //色彩替换（替换亮部和暗部色彩）G
                 * 使用图像的亮度在两个用户指定的颜色之间进行混合
                 *  firstColor：第一和第二种颜色分别指定什么颜色代替图像的暗部和亮色区域。默认值为（0.0,0.0,0.5）amd（1.0,0.0,0.0）。
                 *  secondColor：
                 */
                filter = new GPUImageFalseColorFilter();
                break;
            case 54:
                /**
                 * 硬件优化的可变半径高斯模糊
                 * texelSpacingMultiplier：纹素之间的间距的乘数，范围从0.0到up，默认值为1.0。
                 * 调整这可能会稍微增加模糊强度，但会在结果中引入工件。在接触这一个之前先强烈推荐使用其他参数。
                 * blurRadiusInPixels：用于模糊的半径（以像素为单位），默认值为2.0。这调整高斯分布函数中的sigma变量。
                 *  blurRadiusAsFractionOfImageWidth：
                 *  blurRadiusAsFractionOfImageHeight：设置这些属性将允许模糊半径与图像的大小缩放
                 *  blurPasses：顺序模糊传入图像的次数。越多越好，过滤器越慢。
                 */
                filter = new GPUImageGaussianBlurFilter();
                break;
            case 55:
                /**
                 * //水晶球效果
                 * 与GPUImageSphereRefractionFilter相同，只有图像不反转，玻璃边缘有一点结霜
                 * 中心：应用失真的中心，默认为（0.5,0.5）
                 * radius：失真的半径，范围从0.0到1.0，默认值为0.25
                 *  refractiveIndex：球体折射率，默认值为0.71
                 */
                filter = new GPUImageGlassSphereFilter();
                break;
            case 56:
                /**
                 * //朦胧加暗
                 * 用于添加或删除雾度（类似于UV过滤器）
                 * 距离：施加的颜色的强度。默认值0.-3和.3之间的值最好。
                 * 坡度：颜色变化量。默认值0.-3和.3之间的值最好。
                 */
                filter = new GPUImageHazeFilter();
                break;
            case 57:
                /**
                 * //提亮阴影
                 * 调整图像的阴影和高光
                 * 阴影：增加减轻阴影，从0.0到1.0，默认值为0.0。
                 *  亮点：降低亮度，从1.0到0.0，默认值为1.0。
                 */
                filter = new GPUImageHighlightShadowFilter(0.0f, 1.0f);
                break;


            case 58:
                /**
                 * //桑原(Kuwahara)滤波,水粉画的模糊效果；处理时间比较长，慎用
                 * Kuwahara图像抽象，从Kyprianidis的工作，等。人。在他们的出版物“GPU中的各向异性Kuwahara过滤GPU”集合。
                 * 这产生了油画般的图像，但它的计算量非常昂贵，因此在iPad 2上渲染框架可能需要几秒钟时间。这可能最适用于静止图像。
                 * radius：在整数中指定从中心像素出来的像素数，用于在应用过滤器时进行测试，默认值为4.一个较高的值创建一个更抽象的图像，但是花费更大的处理时间。
                 */
                filter = new GPUImageKuwaharaFilter();
                break;

            case 59:
                /**
                 * 像Photoshop一样的级别调整  色阶
                 * min，max，minOut和maxOut参数是[0，1]范围内的浮点数。
                 *  如果您在[0,255]范围内的Photoshop中有参数，则必须先将其转换为[0，1]。
                 * gamma / mid参数是float> = 0.这与Photoshop中的值相匹配。如果您要将级别应用于RGB以及各个通道
                 * 则需要使用此过滤器两​​次 - 首先是单个通道，然后是所有通道。
                 */
                filter = new GPUImageLevelsFilter();
                break;
            case 60:
                /**
                 *  ////单色
                 * 根据每个像素的亮度将图像转换为单色版本
                 *  强度：特定颜色取代正常图像颜色的程度（0.0 - 1.0，默认值为1.0）
                 *   颜色：使用颜色作为效果的基础，以（0.6,0.45,0.3,1.0）为默认值。
                 */
                filter = new GPUImageMonochromeFilter(1.0f, new float[]{0.6f, 0.45f, 0.3f, 1.0f});
                break;
            case 61:
                /**
                 *  //RGB
                 * 调整图像的各个RGB通道
                 *  红色：每个颜色通道乘以的归一化值。范围为0.0，默认值为1.0。
                 *  绿色：
                 *  蓝色：
                 */
                filter = new GPUImageRGBFilter(1.0f, 1.0f, 1.0f);
                break;


            case 62:
                /**
                 *  //素描
                 * 将视频转换为草图。这只是Sobel边缘检测滤镜，颜色反转
                 * texelWidth：
                 *  texelHeight：这些参数影响检测到的边缘的可见性
                 *  edgeStrength：调整过滤器的动态范围。更高的值导致更强的边缘，但可以饱和强度的颜色空间。默认值为1.0。
                 */
                filter = new GPUImageSketchFilter();
                break;
            case 63:
                /**
                 * //相比上面的效果更细腻，上面是粗旷的画风
                 * 它使用与GPUImageToonFilter类似的过程，只有在高斯模糊之前，才能平滑噪声。
                 * texelWidth：
                 * texelHeight：这些参数影响检测到的边缘的可见性
                 * blurRadiusInPixels：底层高斯模糊的半径。默认值为2.0。
                 * 阈值：边缘检测的灵敏度，较低的值更敏感。范围从0.0到1.0，默认值为0.2
                 * quantizationLevels：最终图像中要表示的颜色级数。默认值为10.0
                 */
                filter = new GPUImageSmoothToonFilter();
                break;

            case 64:
                /**
                 * //球形折射，图形倒立
                 * 通过玻璃球模拟折射
                 * 中心：应用失真的中心，默认为（0.5,0.5）
                 * radius：失真的半径，范围从0.0到1.0，默认值为0.25
                 * refractiveIndex：球体折射率，默认值为0.71
                 */
                filter = new GPUImageSphereRefractionFilter();
                break;
            case 65:
                /**
                 * //漩涡，中间形成卷曲的画面
                 * 在图像上创建漩涡失真
                 * 半径：半径从中心应用失真，默认为0.5
                 * 中心：图像中心（标准化坐标为0 - 1.0），扭曲，默认为（0.5，0.5）
                 * angle：要应用于图像的扭曲量，默认值为1.0
                 */
                filter = new GPUImageSwirlFilter();
                break;
            case 66:
                /**
                 * //形状变化
                 * 这将对图像应用任意的2-D或3-D变换
                 * affineTransform：这需要一个CGAffineTransform来调整2-D中的图像
                 *  transform3D：这是一个CATransform3D来处理3-D中的图像
                 *   ignoreAspectRatio：默认情况下，维护变换后的图像的宽高比，但可以将其设置为“是”，使变换与宽高比无关
                 */
                filter = new GPUImageTransformFilter();
                break;
            case 67:
                /**
                 * //卡通效果（黑色粗线描边）
                 * 这使用Sobel边缘检测在对象周围放置黑色边框，然后量化图像中存在的颜色，以使图像具有类似卡通的质量。
                 * texelWidth：
                 * texelHeight：这些参数影响检测到的边缘的可见性
                 *  阈值：边缘检测的灵敏度，较低的值更敏感。范围从0.0到1.0，默认值为0.2
                 *  quantizationLevels：最终图像中要表示的颜色级数。默认值为10.0
                 */
                filter = new GPUImageToonFilter();
                break;
            case 68:
                /**
                 * //色调曲线
                 * 根据每个颜色通道的样条曲线调整图像的颜色
                 * redControlPoints：
                 *  greenControlPoints：
                 * blueControlPoints：
                 *  rgbCompositeControlPoints：色调曲线采用一系列控制点，它们定义每个颜色分量的样条曲线，或复合组合中的所有三个样条曲线。
                 *  这些存储为NSArray中的NSValue包装的CGPoint，标准化的X和Y坐标为0 - 1。默认值为（0,0），（0.5,0.5），（1,1）。
                 */
                filter = new GPUImageToneCurveFilter();
                break;
            case 69:
                /**
                 * //晕影，形成黑色圆形边缘，突出中间图像的效果
                 * 执行渐晕效果，在边缘淡出图像
                 *  vignetteCenter：tex coords（CGPoint）中的小插件的中心，默认值为0.5,0.5
                 *  vignetteColor：用于小插曲（GPUVector3）的颜色，默认为黑色
                 *  vignetteStart：从vignette效果开始的中心的标准化距离，默认为0.5
                 *  vignetteEnd：从晕影效果结束的中心的归一化距离，默认值为0.75
                 */
                PointF centerPoint = new PointF();
                filter = new GPUImageVignetteFilter(centerPoint, new float[]{0.0f, 0.0f, 0.0f}, 0.3f, 0.75f);
                break;
            case 70:
                /**
                 * //白平横
                 * 调整图像的白平衡
                 * 温度：以ºK调整图像的温度。4000的值非常酷，7000非常温暖。默认值为5000.请注意，4000和5000之间的刻度几乎与5000到7000之间的视觉显着性相当。
                 * 色调：通过调整图像的色调。值-200是非常绿色，200是非常粉红色。默认值为0。
                 */
                filter = new GPUImageWhiteBalanceFilter(5000.0f, 0.0f);
                break;
            default:
                break;
        }
        return filter;
    }

    public static Bitmap getGPUImageFromAssets(Context context, GPUImage gpuImage, int FilterFlag, float count) {
        AssetManager as = context.getAssets();
        InputStream is = null;
        Bitmap bitmap = null;
        try {
            is = as.open("123.jpg");
            bitmap = BitmapFactory.decodeStream(is);
            is.close();
        } catch (IOException e) {
            Log.e("GPUImage", "Error");
        }

        // 使用GPUImage处理图像
        gpuImage = new GPUImage(context);
        gpuImage.setImage(bitmap);
        gpuImage.setFilter(getFilter(FilterFlag,count));
        bitmap = gpuImage.getBitmapWithFilterApplied();
        return bitmap;
    }

    public static Bitmap getGPUImageFromURL(String url) {
        Bitmap bitmap = null;
        try {
            URL iconUrl = new URL(url);
            URLConnection conn = iconUrl.openConnection();
            HttpURLConnection http = (HttpURLConnection) conn;
            int length = http.getContentLength();
            conn.connect();
            // 获得图像的字符流
            InputStream is = conn.getInputStream();
            BufferedInputStream bis = new BufferedInputStream(is, length);
            bitmap = BitmapFactory.decodeStream(bis);
            bis.close();
            is.close();// 关闭流
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bitmap;
    }

    //调整饱和度、亮度等
//    public static void changeSaturation(int curCount) {
//        GPUImageUtil.count = curCount;
//    }

}
