package cn.briug.hdfx.myapplication;

import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import java.io.IOException;
import java.io.InputStream;
import jp.co.cyberagent.android.gpuimage.GPUImage;
import jp.co.cyberagent.android.gpuimage.GPUImageHueFilter;


public class MainActivity extends AppCompatActivity {


    private GPUImage gpuImage;
    //显示处理结果
    private ImageView resultIv;
    private Button btn ;
    private EditText edit,edit_data ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        resultIv =  findViewById(R.id.imageView);
        btn = findViewById(R.id.btnQiehuan);
        edit =findViewById(R.id.edit);
        edit_data = findViewById(R.id.edit_data);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int code =  Integer.parseInt(edit.getText().toString());
                float data = Float.parseFloat(edit_data.getText().toString());
               getPhoto(code,data);
            }
        });

    }

    public void getPhoto(int code,float data){
        //获得Assets资源文件
        AssetManager as = getAssets();
        InputStream is = null;
        Bitmap bitmap = null;
        try {
            //注意名字要与图片名字一致
            is = as.open("123.jpg");
            bitmap = BitmapFactory.decodeStream(is);
            is.close();
        } catch (IOException e) {
            Log.e("GPUImage", "Error");
        }
        // 使用GPUImage处理图像GPUImageHueFilter
        gpuImage = new GPUImage(this);
        gpuImage.setImage(bitmap);
        bitmap = GPUImageUtil.getGPUImageFromAssets(MainActivity.this,gpuImage,code,data);
        gpuImage.setFilter(new GPUImageHueFilter());
//        bitmap = gpuImage.getBitmapWithFilterApplied();
        //显示处理后的图片
        resultIv.setImageBitmap(bitmap);
    }
}
