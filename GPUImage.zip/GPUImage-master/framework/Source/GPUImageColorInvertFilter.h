#import "GPUImageFilter.h"

@interface GPUImageColorInvertFilter : GPUImageFilter
{
}

@end
