#import <UIKit/UIKit.h>

@interface ShowcaseFilterListController : UITableViewController

@end
