#import <UIKit/UIKit.h>

#import "ColorTrackingAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ColorTrackingAppDelegate class]));
    }
}
