#import <Cocoa/Cocoa.h>

@interface SLSSimpleVideoFileFilterWindowController : NSWindowController

@end
