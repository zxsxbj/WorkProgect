#import <Cocoa/Cocoa.h>
#import "ShaderDesignerWindowController.h"

@interface AppDelegate : NSObject <NSApplicationDelegate>
{
    ShaderDesignerWindowController *windowController;
}

@end

