#import <Cocoa/Cocoa.h>
#import "SLSSimpleVideoFilterWindowController.h"

@interface AppDelegate : NSObject <NSApplicationDelegate>
{
    SLSSimpleVideoFilterWindowController *simpleVideoFilterWindowController;
}

@end

